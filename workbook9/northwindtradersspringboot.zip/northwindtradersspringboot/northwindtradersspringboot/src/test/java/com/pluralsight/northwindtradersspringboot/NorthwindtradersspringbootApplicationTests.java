package com.pluralsight.northwindtradersspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NorthwindtradersspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
