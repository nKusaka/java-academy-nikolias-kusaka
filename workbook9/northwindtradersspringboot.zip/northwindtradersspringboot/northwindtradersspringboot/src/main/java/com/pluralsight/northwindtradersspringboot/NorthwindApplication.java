package com.pluralsight.northwindtradersspringboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component
public class NorthwindApplication implements CommandLineRunner {

    @Autowired
    private ProductDao productDao;

    @Override
    public void run(String... args) {
        menu();
    }

    private void menu() {
        Scanner read = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("1. List Products");
            System.out.println("2. Add Product");
            System.out.println("3. Exit");

            String choice = read.nextLine();

            switch (choice) {
                case "1":
                    listProducts();
                    break;

                case "2":
                    addProduct(read);
                    break;

                case "3":
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private void listProducts() {
        for (Product p: productDao.getAll()) {
            System.out.println(p);
        }
    }

    private void addProduct(Scanner read) {
        System.out.print("ID: ");
        int id = Integer.parseInt(read.nextLine());

        System.out.print("Name: ");
        String name = read.nextLine();

        System.out.print("Category: ");
        String category = read.nextLine();

        System.out.print("Price: ");
        double price = Double.parseDouble(read.nextLine());

        productDao.add(new Product(id, name, category, price));
    }
}
